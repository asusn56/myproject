import AmplifierList from "../../components/amplifierComponents/AmplifiersList";
import Container from "../../components/Container";





export const AmplifiersPage: React.FC = () => {


  return (
  

<Container>
  <AmplifierList/>
</Container>


  )
}

export default AmplifiersPage;
